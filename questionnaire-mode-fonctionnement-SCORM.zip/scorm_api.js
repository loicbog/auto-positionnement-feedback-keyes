/* ============================================================
   SCORM 1.2 wrapper
   Gère la communication avec le LMS (Rise Up, Moodle, etc.)
   ============================================================ */

var SCORM = (function() {
  var API = null;
  var initialized = false;
  var findApiTries = 0;
  var MAX_FIND_TRIES = 500;

  // Cherche l'objet API_1484_11 (SCORM 2004) ou API (SCORM 1.2) injecté par le LMS
  function findAPI(win) {
    while (win && !win.API && win.parent && win.parent !== win) {
      findApiTries++;
      if (findApiTries > MAX_FIND_TRIES) return null;
      win = win.parent;
    }
    return win ? win.API : null;
  }

  function getAPI() {
    if (API !== null) return API;
    var api = findAPI(window);
    if (!api && window.opener) api = findAPI(window.opener);
    API = api;
    return api;
  }

  function log(msg) {
    if (window.console && console.log) console.log("[SCORM] " + msg);
  }

  return {
    // Initialise la connexion au LMS
    init: function() {
      var api = getAPI();
      if (!api) {
        log("API SCORM introuvable - mode hors ligne");
        return false;
      }
      var result = api.LMSInitialize("");
      initialized = (result === "true" || result === true);
      log("Initialize: " + initialized);
      return initialized;
    },

    // Marque le module comme complété
    setCompleted: function() {
      if (!initialized) return false;
      var api = getAPI();
      if (!api) return false;
      api.LMSSetValue("cmi.core.lesson_status", "completed");
      api.LMSCommit("");
      log("Statut: completed");
      return true;
    },

    // Sauvegarde la progression (max 4096 caractères en SCORM 1.2)
    saveSuspendData: function(data) {
      if (!initialized) return false;
      var api = getAPI();
      if (!api) return false;
      var str = typeof data === "string" ? data : JSON.stringify(data);
      if (str.length > 4096) {
        log("Suspend data trop longue (" + str.length + " chars), tronquée");
        str = str.substring(0, 4096);
      }
      api.LMSSetValue("cmi.suspend_data", str);
      api.LMSCommit("");
      return true;
    },

    // Récupère la progression sauvegardée
    loadSuspendData: function() {
      if (!initialized) return null;
      var api = getAPI();
      if (!api) return null;
      var data = api.LMSGetValue("cmi.suspend_data");
      if (!data || data === "") return null;
      try {
        return JSON.parse(data);
      } catch (e) {
        return data;
      }
    },

    // Termine la session avec le LMS
    finish: function() {
      if (!initialized) return;
      var api = getAPI();
      if (!api) return;
      api.LMSCommit("");
      api.LMSFinish("");
      initialized = false;
      log("Session terminée");
    },

    isAvailable: function() {
      return initialized;
    }
  };
})();

// Termine la session quand l'apprenant ferme la fenêtre
window.addEventListener("beforeunload", function() {
  SCORM.finish();
});
